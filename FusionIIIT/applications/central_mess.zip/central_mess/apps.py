from django.apps import AppConfig


class CentralMessConfig(AppConfig):
    name = 'applications.central_mess'
